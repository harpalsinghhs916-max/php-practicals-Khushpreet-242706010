Practical 11: Indexed Array

Run: copy this folder into C:\xampp\htdocs\php_practicals\
Then open: http://localhost/php_practicals/Practical_11_Indexed_Array/

The output.txt file contains the expected/sample output.
