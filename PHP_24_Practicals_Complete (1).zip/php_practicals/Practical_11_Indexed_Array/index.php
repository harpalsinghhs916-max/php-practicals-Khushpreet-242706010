<?php
$fruits = ["Apple", "Banana", "Mango", "Orange"];

echo "Indexed Array:<br>";
foreach ($fruits as $index => $fruit) {
    echo "$index : $fruit<br>";
}
?>