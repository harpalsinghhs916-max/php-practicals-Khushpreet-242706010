Practical 24: Sanitize User Input

Run: copy this folder into C:\xampp\htdocs\php_practicals\
Then open: http://localhost/php_practicals/Practical_24_Sanitize_User_Input/

The output.txt file contains the expected/sample output.
