Practical 6: Day Using Switch

Run: copy this folder into C:\xampp\htdocs\php_practicals\
Then open: http://localhost/php_practicals/Practical_06_Day_Using_Switch/

The output.txt file contains the expected/sample output.
