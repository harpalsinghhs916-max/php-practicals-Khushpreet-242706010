Practical 15: String Functions

Run: copy this folder into C:\xampp\htdocs\php_practicals\
Then open: http://localhost/php_practicals/Practical_15_String_Functions/

The output.txt file contains the expected/sample output.
