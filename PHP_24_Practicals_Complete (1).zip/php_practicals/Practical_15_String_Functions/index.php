<?php
$text = "Hello PHP World";

echo "String: $text<br>";
echo "Length: " . strlen($text) . "<br>";
echo "Substring: " . substr($text, 6, 3) . "<br>";
echo "Replace: " . str_replace("PHP", "Web", $text) . "<br>";
echo "Position of PHP: " . strpos($text, "PHP");
?>