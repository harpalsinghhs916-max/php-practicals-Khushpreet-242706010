Practical 16: Current Date and Time

Run: copy this folder into C:\xampp\htdocs\php_practicals\
Then open: http://localhost/php_practicals/Practical_16_Current_Date_and_Time/

The output.txt file contains the expected/sample output.
