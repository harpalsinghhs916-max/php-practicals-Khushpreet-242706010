Practical 2: PHP Variables and Data Types

Run: copy this folder into C:\xampp\htdocs\php_practicals\
Then open: http://localhost/php_practicals/Practical_02_PHP_Variables_and_Data_Types/

The output.txt file contains the expected/sample output.
