<?php
$name = "Khushpreet";
$age = 20;
$marks = 85.5;
$isStudent = true;

echo "String: $name<br>";
echo "Integer: $age<br>";
echo "Float: $marks<br>";
echo "Boolean: " . ($isStudent ? "true" : "false");
?>