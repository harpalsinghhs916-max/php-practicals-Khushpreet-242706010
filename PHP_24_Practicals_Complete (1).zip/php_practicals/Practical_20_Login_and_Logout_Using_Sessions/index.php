<?php
session_start();

if (isset($_GET['logout'])) {
    session_unset();
    session_destroy();
    echo "Logged out successfully.";
    exit;
}

$username = "admin";
$password = "12345";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if ($_POST["username"] === $username && $_POST["password"] === $password) {
        $_SESSION["user"] = $username;
        echo "Login successful. Welcome, " . $_SESSION["user"] . "!<br>";
        echo '<a href="?logout=1">Logout</a>';
    } else {
        echo "Invalid username or password.";
    }
} else {
?>
<form method="post">
    Username: <input type="text" name="username" required><br><br>
    Password: <input type="password" name="password" required><br><br>
    <button type="submit">Login</button>
</form>
<?php } ?>