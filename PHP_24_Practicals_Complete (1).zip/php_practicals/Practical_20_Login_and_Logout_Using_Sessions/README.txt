Practical 20: Login and Logout Using Sessions

Run: copy this folder into C:\xampp\htdocs\php_practicals\
Then open: http://localhost/php_practicals/Practical_20_Login_and_Logout_Using_Sessions/

The output.txt file contains the expected/sample output.
