Practical 4: Even or Odd

Run: copy this folder into C:\xampp\htdocs\php_practicals\
Then open: http://localhost/php_practicals/Practical_04_Even_or_Odd/

The output.txt file contains the expected/sample output.
