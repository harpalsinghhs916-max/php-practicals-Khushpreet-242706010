Practical 5: Largest of Three Numbers

Run: copy this folder into C:\xampp\htdocs\php_practicals\
Then open: http://localhost/php_practicals/Practical_05_Largest_of_Three_Numbers/

The output.txt file contains the expected/sample output.
