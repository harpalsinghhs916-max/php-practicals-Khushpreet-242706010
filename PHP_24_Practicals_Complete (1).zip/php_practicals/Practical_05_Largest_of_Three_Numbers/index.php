<?php
$a = 25;
$b = 48;
$c = 36;

if ($a > $b) {
    if ($a > $c) {
        $largest = $a;
    } else {
        $largest = $c;
    }
} else {
    if ($b > $c) {
        $largest = $b;
    } else {
        $largest = $c;
    }
}

echo "Largest number = $largest";
?>