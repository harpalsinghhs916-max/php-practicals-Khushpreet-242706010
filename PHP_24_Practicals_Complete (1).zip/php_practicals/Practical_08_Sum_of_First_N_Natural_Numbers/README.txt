Practical 8: Sum of First N Natural Numbers

Run: copy this folder into C:\xampp\htdocs\php_practicals\
Then open: http://localhost/php_practicals/Practical_08_Sum_of_First_N_Natural_Numbers/

The output.txt file contains the expected/sample output.
