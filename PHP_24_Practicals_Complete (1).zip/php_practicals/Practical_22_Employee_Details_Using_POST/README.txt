Practical 22: Employee Details Using POST

Run: copy this folder into C:\xampp\htdocs\php_practicals\
Then open: http://localhost/php_practicals/Practical_22_Employee_Details_Using_POST/

The output.txt file contains the expected/sample output.
