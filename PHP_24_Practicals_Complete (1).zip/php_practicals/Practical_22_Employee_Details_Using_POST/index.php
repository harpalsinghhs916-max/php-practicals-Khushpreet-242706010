<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = htmlspecialchars($_POST["name"]);
    $id = htmlspecialchars($_POST["id"]);
    $department = htmlspecialchars($_POST["department"]);
    echo "<h3>Submitted Employee Details</h3>";
    echo "Name: $name<br>Employee ID: $id<br>Department: $department";
} else {
?>
<form method="post">
    Name: <input type="text" name="name" required><br><br>
    Employee ID: <input type="text" name="id" required><br><br>
    Department: <input type="text" name="department" required><br><br>
    <button type="submit">Submit</button>
</form>
<?php } ?>