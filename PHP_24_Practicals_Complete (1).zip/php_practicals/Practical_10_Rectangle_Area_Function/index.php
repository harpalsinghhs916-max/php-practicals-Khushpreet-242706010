<?php
function rectangleArea($length, $width) {
    return $length * $width;
}

$length = 10;
$width = 6;

echo "Length = $length<br>";
echo "Width = $width<br>";
echo "Area of rectangle = " . rectangleArea($length, $width);
?>