Practical 10: Rectangle Area Function

Run: copy this folder into C:\xampp\htdocs\php_practicals\
Then open: http://localhost/php_practicals/Practical_10_Rectangle_Area_Function/

The output.txt file contains the expected/sample output.
