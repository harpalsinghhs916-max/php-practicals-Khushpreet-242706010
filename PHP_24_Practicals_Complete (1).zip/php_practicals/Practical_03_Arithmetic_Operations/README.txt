Practical 3: Arithmetic Operations

Run: copy this folder into C:\xampp\htdocs\php_practicals\
Then open: http://localhost/php_practicals/Practical_03_Arithmetic_Operations/

The output.txt file contains the expected/sample output.
