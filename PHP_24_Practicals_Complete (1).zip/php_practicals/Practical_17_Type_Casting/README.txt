Practical 17: Type Casting

Run: copy this folder into C:\xampp\htdocs\php_practicals\
Then open: http://localhost/php_practicals/Practical_17_Type_Casting/

The output.txt file contains the expected/sample output.
