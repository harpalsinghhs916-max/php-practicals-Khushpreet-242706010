<?php
$intValue = 25;
$floatValue = 12.75;
$stringValue = "100";

$floatFromInt = (float)$intValue;
$intFromFloat = (int)$floatValue;
$intFromString = (int)$stringValue;

echo "Integer to Float: $floatFromInt (" . gettype($floatFromInt) . ")<br>";
echo "Float to Integer: $intFromFloat (" . gettype($intFromFloat) . ")<br>";
echo "String to Integer: $intFromString (" . gettype($intFromString) . ")";
?>