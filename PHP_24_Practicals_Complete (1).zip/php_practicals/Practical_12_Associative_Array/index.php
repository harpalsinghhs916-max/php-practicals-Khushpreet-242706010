<?php
$students = [
    "Aman" => 85,
    "Simran" => 92,
    "Riya" => 78
];

echo "Student Marks:<br>";
foreach ($students as $name => $marks) {
    echo "$name : $marks<br>";
}
?>