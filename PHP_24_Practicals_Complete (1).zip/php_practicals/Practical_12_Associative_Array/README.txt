Practical 12: Associative Array

Run: copy this folder into C:\xampp\htdocs\php_practicals\
Then open: http://localhost/php_practicals/Practical_12_Associative_Array/

The output.txt file contains the expected/sample output.
