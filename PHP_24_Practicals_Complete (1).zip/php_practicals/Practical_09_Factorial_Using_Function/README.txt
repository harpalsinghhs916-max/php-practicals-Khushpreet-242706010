Practical 9: Factorial Using Function

Run: copy this folder into C:\xampp\htdocs\php_practicals\
Then open: http://localhost/php_practicals/Practical_09_Factorial_Using_Function/

The output.txt file contains the expected/sample output.
