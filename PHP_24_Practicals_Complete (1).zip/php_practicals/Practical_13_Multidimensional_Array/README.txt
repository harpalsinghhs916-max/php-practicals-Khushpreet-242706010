Practical 13: Multidimensional Array

Run: copy this folder into C:\xampp\htdocs\php_practicals\
Then open: http://localhost/php_practicals/Practical_13_Multidimensional_Array/

The output.txt file contains the expected/sample output.
