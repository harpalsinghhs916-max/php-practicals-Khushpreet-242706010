<?php
$students = [
    ["Aman", 85],
    ["Simran", 92],
    ["Riya", 78]
];

echo "Name & Marks:<br>";
foreach ($students as $student) {
    echo "Name: {$student[0]}, Marks: {$student[1]}<br>";
}
?>