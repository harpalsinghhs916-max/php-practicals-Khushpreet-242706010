<?php
$errors = [];
$success = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["name"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $mobile = trim($_POST["mobile"] ?? "");

    if ($name === "") $errors[] = "Name is required.";
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Invalid email address.";
    if (!preg_match("/^[0-9]{10}$/", $mobile)) $errors[] = "Mobile number must contain exactly 10 digits.";

    if (!$errors) {
        $success = "Registration successful!";
    }
}
?>
<form method="post">
    Name: <input type="text" name="name" required><br><br>
    Email: <input type="email" name="email" required><br><br>
    Mobile: <input type="text" name="mobile" required><br><br>
    <button type="submit">Register</button>
</form>
<?php
foreach ($errors as $error) echo "<p>$error</p>";
if ($success) echo "<p>$success</p>";
?>