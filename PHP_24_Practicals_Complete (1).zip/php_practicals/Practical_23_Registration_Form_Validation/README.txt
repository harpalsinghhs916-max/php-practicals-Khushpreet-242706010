Practical 23: Registration Form Validation

Run: copy this folder into C:\xampp\htdocs\php_practicals\
Then open: http://localhost/php_practicals/Practical_23_Registration_Form_Validation/

The output.txt file contains the expected/sample output.
