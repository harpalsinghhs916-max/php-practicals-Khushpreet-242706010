Practical 19: Create and Retrieve Cookie

Run: copy this folder into C:\xampp\htdocs\php_practicals\
Then open: http://localhost/php_practicals/Practical_19_Create_and_Retrieve_Cookie/

The output.txt file contains the expected/sample output.
