<?php
setcookie("student", "Khushpreet", time() + 3600, "/");
?>
<!DOCTYPE html>
<html>
<body>
<?php
if (isset($_COOKIE["student"])) {
    echo "Cookie value: " . $_COOKIE["student"];
} else {
    echo "Cookie created. Refresh the page to retrieve it.";
}
?>
</body>
</html>