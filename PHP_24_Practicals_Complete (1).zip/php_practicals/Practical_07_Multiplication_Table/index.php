<?php
$num = 7;

echo "Multiplication Table of $num<br><br>";
for ($i = 1; $i <= 10; $i++) {
    echo "$num × $i = " . ($num * $i) . "<br>";
}
?>