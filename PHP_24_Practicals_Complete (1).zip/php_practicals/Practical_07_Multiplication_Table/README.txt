Practical 7: Multiplication Table

Run: copy this folder into C:\xampp\htdocs\php_practicals\
Then open: http://localhost/php_practicals/Practical_07_Multiplication_Table/

The output.txt file contains the expected/sample output.
