<?php
if ($_SERVER["REQUEST_METHOD"] === "GET" && isset($_GET["submitted"])) {
    $name = htmlspecialchars($_GET["name"]);
    $roll = htmlspecialchars($_GET["roll"]);
    $course = htmlspecialchars($_GET["course"]);
    echo "<h3>Submitted Student Details</h3>";
    echo "Name: $name<br>Roll No: $roll<br>Course: $course";
} else {
?>
<form method="get">
    <input type="hidden" name="submitted" value="1">
    Name: <input type="text" name="name" required><br><br>
    Roll No: <input type="text" name="roll" required><br><br>
    Course: <input type="text" name="course" required><br><br>
    <button type="submit">Submit</button>
</form>
<?php } ?>