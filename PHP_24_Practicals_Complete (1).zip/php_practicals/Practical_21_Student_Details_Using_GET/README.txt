Practical 21: Student Details Using GET

Run: copy this folder into C:\xampp\htdocs\php_practicals\
Then open: http://localhost/php_practicals/Practical_21_Student_Details_Using_GET/

The output.txt file contains the expected/sample output.
