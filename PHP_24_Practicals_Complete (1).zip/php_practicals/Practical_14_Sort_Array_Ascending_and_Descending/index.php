<?php
$numbers = [45, 12, 78, 23, 9];

$ascending = $numbers;
sort($ascending);

$descending = $numbers;
rsort($descending);

echo "Original: " . implode(", ", $numbers) . "<br>";
echo "Ascending: " . implode(", ", $ascending) . "<br>";
echo "Descending: " . implode(", ", $descending);
?>