Practical 14: Sort Array Ascending and Descending

Run: copy this folder into C:\xampp\htdocs\php_practicals\
Then open: http://localhost/php_practicals/Practical_14_Sort_Array_Ascending_and_Descending/

The output.txt file contains the expected/sample output.
