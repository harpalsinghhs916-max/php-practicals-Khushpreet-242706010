Practical 1: Hello World

Run: copy this folder into C:\xampp\htdocs\php_practicals\
Then open: http://localhost/php_practicals/Practical_01_Hello_World/

The output.txt file contains the expected/sample output.
