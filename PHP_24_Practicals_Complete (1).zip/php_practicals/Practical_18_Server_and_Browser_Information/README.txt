Practical 18: Server and Browser Information

Run: copy this folder into C:\xampp\htdocs\php_practicals\
Then open: http://localhost/php_practicals/Practical_18_Server_and_Browser_Information/

The output.txt file contains the expected/sample output.
